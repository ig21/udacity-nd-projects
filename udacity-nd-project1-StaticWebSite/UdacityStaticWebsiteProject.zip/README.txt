Deploy Static Website on AWS

Website project --> deploy a static website to AWS using S3, CloudFront, and IAM.

The files included are: 

Document with screenshots of every step result

Readme file (this document)


